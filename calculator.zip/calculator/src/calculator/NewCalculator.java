/* Создать приложение «Калькулятор» с 3 пунктами меню:
-Операции: включает 4 подпункта (+,-,*,/),с соответствующей обработкой каждого подпункта.
-Установка цвета: цвет текста и цвет фона фрейма.
-Выход.
При выборе одного из подпунктов пункта меню «Операции»
должно появляться предыдущее диалоговое окно, 
при закрытии которого результат должен появляться на основном фрейме.*/

package calculator;

import java.awt.*;
import java.awt.event.*;

import javax.swing.JDialog;

public class NewCalculator extends Frame {
	Color c;
	Color c1;

	int t;
	
	double res;
	
	private MenuBar m;
	
	private Menu m1;
	private Menu m2;
	private Menu m3;
	private Menu m4;
	
	private MenuItem mi11;
	private MenuItem mi12;
	private MenuItem mi13;
	private MenuItem mi14;
	
	private MenuItem mi21;
	private MenuItem mi22;
	private MenuItem mi23;
	private MenuItem mi31;
	private MenuItem mi32;
	private MenuItem mi33;
	private MenuItem mi41;
	
	Dialog dlg;
	Dialog dlg1;
	
	Label l;
	Label l1;
	Label l2;
	Label l3;
	Label l4;
	
	TextField tf;
	TextField tf1;
	TextField tf2;
	TextField tf3;
	
	Button b1;
	Button b2;
	Button b3;
	Button b4;
	
	public NewCalculator(){
		c1=new Color(255,255,255);
		c=new Color(0,0,0);
		
		this.setTitle("My calculator");
		this.setSize(800, 800);
		this.setLocation(100, 100);
		
		m = new MenuBar();
		
		m1 = new Menu("Операции");
		m2 = new Menu("Цвет текста фрейма");
		m3 = new Menu("Цвет фона фрейма");
		m4 = new Menu("Выход");
		
		mi11 = new MenuItem("+");
		mi12 = new MenuItem("--");
		mi13 = new MenuItem("*");
		mi14 = new MenuItem("/");
		mi21 = new MenuItem("красный");
		mi22 = new MenuItem("зеленый");
		mi23 = new MenuItem("синий");
		mi31 = new MenuItem("красный");
		mi32 = new MenuItem("зеленый");
		mi33 = new MenuItem("синий");
		mi41 = new MenuItem("выйти");
		
		m.add(m1);
		m.add(m2);
		m.add(m3);
		m.add(m4);

		m1.add(mi11);
		m1.add(mi12);
		m1.add(mi13);
		m1.add(mi14);

		m2.add(mi21);
		m2.add(mi22);
		m2.add(mi23);
		
		m3.add(mi31);
		m3.add(mi32);
		m3.add(mi33);
		
		m4.add(mi41);
		
		this.setMenuBar(m);
		this.setVisible(true);
		
		l=new Label("Результат=");
		tf=new TextField("");
	
		this.setLayout(new FlowLayout());
		this.add(l);
		this.add(tf);
		
		
		dlg = new Dialog(dlg);
		dlg.setSize(600,600);
		dlg.setVisible(false);
		
		dlg1 = new JDialog(dlg);
		dlg1.setSize(600,600);
		dlg1.setVisible(false);
		
		l1=new Label("A=");
		l2=new Label("B=");
		l3=new Label("Введите текст");
		l4=new Label("Ошибка!На 0 делить нельзя!!!");
		
		tf1=new TextField();
		tf2=new TextField();
		tf3=new TextField("Sum=");
		
		b1=new Button("OK");
		b2=new Button("Cancel");	
		b3=new Button("Обнулить все");
		b4=new Button("OK");
		
		dlg.setLayout(new GridLayout(3,3));
		dlg.add(l1);
		dlg.add(tf1);
		dlg.add(l2);
		dlg.add(tf2);
		dlg.add(l3);
		dlg.add(tf3);
		dlg.add(b3);
		dlg.add(b1);
		dlg.add(b2);
		
		mi11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlg.setVisible(true);
				tf3.setText("Sum=");
				t=0;
			}
			});
		
		mi12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlg.setVisible(true);
				tf3.setText("Sub=");
				t=1;
			}
			});
		
		mi13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlg.setVisible(true);
				tf3.setText("Mul=");
				t=2;
			}
			});
		
		mi14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlg.setVisible(true);
				tf3.setText("Div=");
				t=3;
			}
			});
		
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(t==0){
					res=Double.parseDouble(tf1.getText())+Double.parseDouble(tf2.getText());
				    tf3.setText(tf1.getText()+"+"+tf2.getText()+"="+res);
				}
				if(t==1){
					res=Double.parseDouble(tf1.getText())-Double.parseDouble(tf2.getText());
					tf3.setText(tf1.getText()+"-"+tf2.getText()+"="+res);
				}
				if(t==2){
					res=Double.parseDouble(tf1.getText())*Double.parseDouble(tf2.getText());
					tf3.setText(tf1.getText()+"*"+tf2.getText()+"="+res);
				}
				if(t==3){
					res=Double.parseDouble(tf1.getText())/Double.parseDouble(tf2.getText());
					tf3.setText(tf1.getText()+"/"+tf2.getText()+"="+res);
					if((res==Double.POSITIVE_INFINITY)||(res==Double.NEGATIVE_INFINITY)){	 
						 dlg1.setVisible(true);
						 dlg1.setLayout(new FlowLayout());
						 dlg1.add(l4);
						 dlg1.add(b4); 
					 }
				}
			}
			});
		
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlg.setVisible(false);
				String s=String.valueOf(res);
				tf.setText(s);
			}
			});
		
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tf1.setText("0");
				tf2.setText("0");
				tf3.setText("Выберите операцию");
			}
			});
		
		b4.addActionListener(new ActionListener()
		{
		 public void actionPerformed(ActionEvent e)
		 {
			 dlg1.setVisible(false);
		 }
		});
		
		mi41.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					dispose();
					System.exit(0);
				
			
			}
			});
		
		mi21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.RED;
			}
			});
		
		mi22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.GREEN;
			}
			});
		
		mi23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c=Color.BLUE;
			}
			});
		
		
		
		mi31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1=Color.RED;
			}
			});
		
		mi32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1=Color.GREEN;
			}
			});
		
		mi33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				c1=Color.BLUE;
			}
			});
		repaint();	
	}
	
	public void paint(Graphics g){
		this.setBackground(c1);
		this.setForeground(c);
	}
	
	public static void main(String[] args){
		NewCalculator my=new NewCalculator();
		my.setVisible(true);
	}
}
